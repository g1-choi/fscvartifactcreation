%selectcsc=12;   %CSC channel number change here
%pathnlx='Z:\data_MIT\patra_fscv\patra_chronic98b_07022018\spikes\';

%load lfp samples & eye data
[samples, nlxFileNames, TS,header,nlxjunk]=ephys_getCSCwheader(selectcsc,pathnlx);
%TS here is vector nlx timestamps in seconds
ratelfp=getSampleRate(TS);

ratelfp=30e3;           %DEFAULT


%get events file 
%direvents=dir([pathnlx '*.nev']);
%fileevents=[pathnlx direvents.name];       %get events file name, this gets re-exported to new folder also
%load neuralynx events file (mat converted from dg_nlx2mat.m
%load dg_Nlx2Mat_EventStrings, dg_Nlx2Mat_Timestamps, dg_Nlx2Mat_TTL
%dg_Nlx2Mat(fileevents); %Convert .nev file to .mat file and save to same directroy, load next
%load([[fileevents(1:end-4)] '.mat']);
%nlx_ts=dg_Nlx2Mat_Timestamps.*1e-6;      %convert to sec (timestamps for events)
dg_Nlx2Mat_Samples=samples{1};
dg_Nlx2Mat_Timestamps=TS*1e6;