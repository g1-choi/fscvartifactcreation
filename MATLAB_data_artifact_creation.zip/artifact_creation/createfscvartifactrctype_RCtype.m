%temppath='Z:\data_MIT\patra_fscv\patra_chronic98b_07022018\spikes\artificial\';

savecsc=append('csc',num2str(selectcsc),'_rcType');

t=dg_Nlx2Mat_Timestamps; %in microseconds
kRC=.5;                 %ratio of R current to C current (ideal cap)
tau=.75e-3;       %rise/decay constant (s)
targsize=6;             %artifact amplitude scale, 6 about nomral, 15 to hit rail
settletime=0;

rails=[-1e-3 1e-3];
scale=nanstd(dg_Nlx2Mat_Samples)*targsize;
numsamples=length(dg_Nlx2Mat_Samples);
fulldur=floor(numsamples/30e3);         %seconds recording
afs=10;         %artifact rate
rate=30000;
dur=8.5e-3;     %duration of fscv waveform
halfdur=dur/2;
ts=0:1/rate:halfdur;        %half cycle duration timestamps
alpha=1/tau;
waveup=1-exp(-ts*alpha);
Ai=waveup(end);         %last value from wave up is starting amp for wave down
wavedown=Ai.*exp(-ts*alpha);
padlength=1e-3;

if settletime>0
    %add longer time constant for coming down (as seen with clipping fscv
    %artifacts)
    if wavedown(end)~=0
        %interpolate smooth points from end of wave to zero's inserted after
        wavepadout=interp1([1 padlength*rate],[wavedown(end) 0],1:padlength*rate,'spline');
        paddedwave=wavedown;
        paddedwave([length(wavedown):length(wavedown)+padlength*rate-1])=wavepadout;
        wavedown=paddedwave;
    end
    tsdown=[ts(1:end-1) ts(end):1/rate:ts(end)+settletime];
    wavedown=[wavedown zeros(1,length(tsdown)-length(wavedown))];
    alpha=1/(settletime/2);
    wavedown=.15*Ai.*exp(-tsdown*alpha)+wavedown;
    padlength=settletime/4;
end
wave=[waveup wavedown];
capwave=[repmat(1,1,length(waveup)) repmat(-1,1,length(waveup))];
cyclet=0:1/rate:1/afs-1/rate;
%artifactwave=wave*kRC+capwave*(1-kRC);
rwave=[wave zeros(1,length(cyclet)-length(wave))];      %make duration of artifact pulse rate
cwave=[capwave zeros(1,length(cyclet)-length(capwave))];
artifactwave=rwave*kRC+cwave*(1-kRC);
    periodwave=artifactwave;
if artifactwave(length(wave))~=0
    %interpolate smooth points from end of wave to zero's inserted after
    wavepadout=interp1([1 padlength*rate],[artifactwave(length(wave)) 0],1:padlength*rate,'spline');
    paddedwave=periodwave;
    paddedwave([length(wave):length(wave)+padlength*rate-1])=wavepadout;
    periodwave=paddedwave;
else
    periodwave=artifactwave;
end

nums=fulldur*afs;
fullwave=repmat(periodwave,1,nums);
artifact=fullwave.*scale;
artifact(end:numsamples)=0;
sumsignal=artifact+dg_Nlx2Mat_Samples;
sumsignal(sumsignal<rails(1))=rails(1);
sumsignal(sumsignal>rails(2))=rails(2);

tt=[19 21];
tstamp=t(tt(1)*rate:tt(2)*rate)*1e-6;
figure('color',[1 1 1],'position',[100 100 1400 700]); 
plot(tstamp-tstamp(1),dg_Nlx2Mat_Samples((tt(1)*rate:tt(2)*rate)))
hold on; plot(tstamp-tstamp(1),sumsignal((tt(1)*rate:tt(2)*rate)))
legend('original','w/ artificial artifact');
ylim([-3e-4 .4e-3])
xlabel('time (s)')
ylabel('V');
set(findall(gca,'-property','FontSize'),'FontSize',16)
title('RC type')

old_waveform=dg_Nlx2Mat_Samples;
dg_Nlx2Mat_Samples=sumsignal;

ADBitVoltstr={};
ADBitVolts=[];
 for k = 1:length(header)
    if regexp(header{k}, '^\s*-ADBitVolts\s+')
        ADBitVoltstr = regexprep(header{k}, ...
            '^\s*-ADBitVolts\s+', '');
        ADBitVolts = str2num(ADBitVoltstr);                           
    end
 end

%convert to ad units for nlx               
dg_Nlx2Mat_Samples= dg_Nlx2Mat_Samples./ADBitVolts; %in ad units for nlx, see header
dg_Nlx2Mat_Samples=round(dg_Nlx2Mat_Samples);   
dg_Nlx2Mat_SamplesUnits='AD'; 
nlx_TS=dg_Nlx2Mat_Timestamps(1:512:end);    %get TS every 512 timestamps to put into frames
samplesnlx=reshape(dg_Nlx2Mat_Samples,512,length(dg_Nlx2Mat_Samples)/512);   %reshape samples into 512 length frames
dg_writeCSC([temppath savecsc '.ncs'], nlx_TS, samplesnlx, header,'nlxjunk',nlxjunk);   %need to write junk that came with origianl nlx file in order to read into plexon