                % bizarrely, Mat2NlxEV_411 does not write event strings in
                % append mode unless you also "write" the header (which of
                % course *never* writes in append mode).
